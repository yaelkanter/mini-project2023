package common;

public interface ChatIF
{
    void display(final String str);
}